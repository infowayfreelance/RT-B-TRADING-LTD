# RT&B Trading Ltd — Original Homepage Concept

A fully responsive, single-page construction and building materials homepage. Built with plain HTML, CSS, and JavaScript. No frameworks or installation are required.

## Preview

Open `index.html` in a browser, or run a local server:

```sh
python -m http.server 8000
```

Then visit http://localhost:8000 .

## Deploy

Upload the folder to any static host, Netlify, or Vercel. On Vercel, create a new project from this folder and use the **Other** framework preset; no build command or output directory is needed. All internal navigation links work on the one-page design.

## Important before launch

- The client supplied only the email prefix `sales@`. It is shown as provided, **without a clickable mailto link**. Ask for the full address before launch. No contact form was added, because there is no confirmed recipient or form backend.
- The supplied address is **2 Argyll Road, Stoke-on-Trent, ST3 4RB**.
- Service ideas were taken from the reference site: new builds, extensions, loft conversions, structural works and groundworks. Materials categories are illustrative and subject to client confirmation. **Confirm that RT&B actually provides each service/category before publishing.**
- No client testimonials, years in business, certifications, insurance cover, phone numbers, inventory/stock guarantees or project portfolio were invented.
- Images are illustrative stock photos loaded from Unsplash while online, not photos of RT&B projects. The bundled original architectural SVG artwork remains visible when those photos cannot load. Replace with client photos if available.
- The page includes SEO metadata, accessibility support, a responsive navigation menu, reduced-motion support and a directions link. The map panel is a decorative illustration, not a live map embed.

## Files

`index.html`, `styles.css`, `app.js`, `assets/*.svg`.

## Stock photo references (Unsplash)

- Phil Hearing — https://unsplash.com/photos/house-under-construction-with-scaffolding-and-bricks-qwltbMlICgs
- Troy Mortier — https://unsplash.com/photos/construction-site-with-building-materials-and-fencing-9eIYCmYTbLA
- Tanya Barrow — https://unsplash.com/photos/modern-building-under-construction-next-to-old-brick-building-3R3nqpK5-9E
- Salvador Rios — https://unsplash.com/photos/a-building-under-construction-with-scaffolding-iUsJNCu8vBo
- Zane Bolen — https://unsplash.com/photos/construction-site-with-scaffolding-and-building-materials-5oIUnZ1nPZs

Photo sources are licensed by their respective authors under the Unsplash License where indicated on Unsplash. Client should review and approve all imagery before going live.
